function fibonacci(n) {
  let a = 0;
  let b = 1;

  for (i = 0; i < n; i++) {
    console.log(a);
    [a, b] = [b, a + b];
  }
}

fibonacci(10);
