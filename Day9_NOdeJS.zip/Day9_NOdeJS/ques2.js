var fs = require("fs");

let table = "";

for (let i = 1; i <= 10; i++) {
  table += `3 x ${i} = ${3 * i}\n`;
}

fs.writeFile("table.txt", table, (err) => {
  if (err) {
    console.error("Error writing to file", err);
  } else {
    console.log("Table of 3 written to table.txt");
  }
});
