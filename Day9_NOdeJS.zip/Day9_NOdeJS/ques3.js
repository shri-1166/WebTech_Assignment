var fs = require("fs");

const filename = "dummy.txt";
const data =
  "This is a dummy file in that \n we have writtent a lot of data and a texts djjkkjnm  jdkjjdkkjcz CIIm dsias   diDNAQJUSDJW";

fs.writeFileSync(filename, data);
console.log("Data written to file", filename);

const fileinf = fs.readFileSync(filename, "utf-8");
console.log("Content");
console.log(fileinf);
