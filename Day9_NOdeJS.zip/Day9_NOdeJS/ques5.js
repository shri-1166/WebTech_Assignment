const greet = require("./greeting");

greet();
